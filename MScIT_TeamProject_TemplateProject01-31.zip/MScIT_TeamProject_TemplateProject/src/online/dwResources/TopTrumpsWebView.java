package online.dwResources;

public class TopTrumpsWebView {
//	private TopTrumpsModel model;
//	
//	public TopTrumpsWebView(TopTrumpsModel model) {
//		this.model = model;
//	}

	
	
	

	
	
	public void drawCardStage() {
		
		
	
	}
	
	
	
	
	
}
